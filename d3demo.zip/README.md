
## To Start Application

npm install
npm start
